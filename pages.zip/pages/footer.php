<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-opacity w3-teal w3-medium">
 
  <p class="w3-medium"><i>PROJECT BY <br>Kangkanmoni Brahma<br>Md Nur Islam Rohman<br>Sanjaya Yadav</i></p>
</footer>