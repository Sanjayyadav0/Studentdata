<?php
session_start ();

if (! (isset ( $_SESSION ['login'] ))) {
	
	header ( 'location:../index.php' );
} 
   
    include('../config/DbFunction.php');
    $obj=new DbFunction();
	$rs=$obj->showCourse();


	if(isset($_GET['del']))
    {
           
          $obj->del_course(intval($_GET['del']));
          
       
  }

?> 
 
<?php include('../inc/navbar2.php'); ?>   

<div class="w3-content" style="max-width:2000px; margin-top:16px">

  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">
    <?php include('../inc/mtech.php'); ?>


  </div>

</div> 
    


<?php include('footer.php'); ?>   

</body>

</html>
