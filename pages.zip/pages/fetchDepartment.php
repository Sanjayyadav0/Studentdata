<?php 

	$db=mysqli_connect('localhost','root','','project');
	if(!$db)
	{
		echo "connection error";
		exit;
	}
	else
	{
		$courseName=$_POST['courseName'];
		$sql="SELECT dshort From department WHERE cshort='".$courseName."'";
		$result=mysqli_query($db,$sql); ?>
		<option value="" disabled selected>Select Department</option>

		<?php
		while($row=mysqli_fetch_array($result))
		{
			?>
			<option value="<?php echo $row[0] ?>"><?php echo $row[0]; ?></option>
			<?php
		}
	}

 ?>