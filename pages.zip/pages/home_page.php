<?php include('../inc/navbar2.php'); ?>
<?php include('../inc/btech.php'); ?>