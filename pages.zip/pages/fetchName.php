<?php 

	$db=mysqli_connect('localhost','root','','project');
	if(!$db)
	{
		echo "connection error";
		exit;
	}
	else
	{
		$category=$_POST['category'];

		$sql1="SELECT  fname From student WHERE scholarship IS NULL AND category='".$category."' ";
		$result1=mysqli_query($db,$sql1);

		$sql="SELECT  CONCAT(fname,' ',mname,' ', lname) AS name From student WHERE scholarship IS NULL AND category='".$category."' ";
		$result=mysqli_query($db,$sql);

		while($row=mysqli_fetch_array($result))
		{
			$row1=mysqli_fetch_array($result1)
			?>
			<option value="<?php echo $row1[0] ?>"><?php echo strtoupper( $row[0]); ?></option>
			<?php
		}
	}

 ?>