
<nav class="navbar navbar-default navbar-static-top"  role="navigation"
      style="margin-bottom: 0">
			<div class="navbar-header" >
				<button type="button" class="navbar-toggle" data-toggle="collapse"
					data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span> 
                    <span class="icon-bar"></span> 
                    <span class="icon-bar"></span> 
                    <span class="icon-bar"></span>
				</button>   
        <a class="navbar-brand " href="#">MIZORAM UNIVERSITY</a>
         <a class="navbar-brand" href="#">Student Information System</a>
			</div>
				<div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        <li>
                   <a href="home.php"><span class="glyphicon glyphicon-home" style="font-size:18px;"></span>  Home</a>
                        </li>
                        <li>
                            <a href="#"><span class="glyphicon glyphicon-education" style="font-size:18px;"></span>  Course<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">                                
                                <li>
                                    <a href="view-course.php">View</a>
                                </li>
                            </ul>
                            </li>
                
                 <li>
                            <a href="#"><span class="glyphicon glyphicon-briefcase" style="font-size:18px;"></span>  Department<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">                                
                                <li>
                                    <a href="view-department.php">View</a>
                                </li>
                            </ul>
                           
                        </li>
                        
                   <li>
                            <a href="#"><span class="glyphicon glyphicon-user" style="font-size:18px;"></span>  Students<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">                                
                                <li>
                                    <a href="register.php">Register Student</a>
                                </li>                        
                                                         
                                <li>
                                    <a href="view.php">View Students</a>
                                </li>
                                <li>
                                    <a href="view-outstatestudent.php">Out-Of-State Students</a>
                                </li>  
                                <li>
                                    <a href="view-homestatestudent.php">Home-State Students</a>
                                </li>                                
                            </ul>
                  </li>     
                  <li>
                            <a href="#"><span class="glyphicon glyphicon-user" style="font-size:18px;"></span>  Scholarship<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">                                
                                <li>
                                    <a href="newscholership.php"> Newly Registered</a>
                                </li>                        
                                                         
                                <li>
                                    <a href="view-scholarship.php">View Scholership Details</a>
                                </li>                                
                            </ul>
                  </li>     
                  <li>
                            <a href="#"><span class="glyphicon glyphicon-user" style="font-size:18px;"></span>  User<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">                                
                                <li>
                                    <a href="registeradmin.php">Add Administrator</a>
                                </li>                        
                                                         
                                <li>
                                    <a href="registeruser.php">Add User</a>
                                </li>                                
                            </ul>
                  </li>                               
                   
                   <li>
                            <a href="logout.php"><span class="glyphicon glyphicon-off style="font-size:18px;""></span>  Logout<span class="fa arrow"></span></a>
                  </li>
                  </ul>      				  
                </div>
               
            </div>
            
        </nav>