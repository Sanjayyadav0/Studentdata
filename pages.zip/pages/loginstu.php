<?php 
session_start();
if(isset($_POST['submit'])){
    
     include('../config/DbFunction2.php');
     $obj=new DbFunction2();
     $_SESSION['login']=$_POST['id'];
     $obj->login($_POST['id'],$_POST['password']);
}
    

?><!DOCTYPE html>
<html>
<head>
    <title>Student Information System</title>
    <?php include('metabootstrap.php'); //if we comment up this inclusion then every bootstrap properties will be gone. i.e it will be a raw HTML page
    ?>
    <style type="text/css">
        .box{
            box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
            position: relative;
            border-radius: 3px;
            background: #ffffff;
            border-top: 3px solid #d2d6de;
            margin-bottom: 20px;
            width: 100%;
        }
        .custom{
            width: 70%;
        }
        .box1{
            background: #B0C4DE;
           
        }
        .custom1{
            
            text-align: center;
        }
        .custom3{
            
           width: 20%;
        }
    </style>
</head>
<body>
    <div class="jumbotron text-center box1">
        <h1>Student Information System</h1>
        <h2>User</h2>
        <p>Log In Panel</p>
    </div>
    <div class="container custom" >
        <form method="post">
            <div class="col-md-6 box">
                <div class="form-group" style="padding-top: 2%">
                        <label for="username">User ID:</label>
                      
                         <input class="form-control " placeholder="Login Id"  id="id" name="id" type="text" autofocus autocomplete="off">
                    
                </div>
                <div class="form-group" style="padding-top: 2%">
                        <label for="password">Password:</label>
                        
                         <input class="form-control " placeholder="Password" id="password" name="password" type="password" value="">
                </div>
                <div align="center" class="form-group">
                    
                    <input type="submit" value="Login" name="submit" class="btn btn-lg btn-success custom3">
                </div>
                <div align="center" class="form-group">
                    
                    <a href="login.php">Login as Administrator</a>
                </div>
                
                
                
                
                
            </div>
            
        </form>
        
    </div>>
     <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
    <script src="../dist/js/jquery-1.3.2.js" type="text/javascript"></script>
    <script src="../dist/css/jquery.validate.js" type="text/javascript"></script>
    <script type="text/javascript">
            
            jQuery(function(){
                jQuery("#id").validate({
                    expression: "if (VAL.match(/^[a-z]$/)) return true; else return false;",
                    message: "Should be a valid id"
                });
                jQuery("#password").validate({
                    expression: "if (VAL.match(/^[a-z]$/)) return true; else return false;",
                    message: "Should be a valid password"
                });
                
            });
            
    </script>
</body>
</html>