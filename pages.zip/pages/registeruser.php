<?php
session_start ();

if (! (isset ( $_SESSION ['login'] ))) {
	
	header ( 'location:../index.php' );
}
include('../config/DbFunction.php');
	$obj=new DbFunction();
	$rs=$obj->showCourse();
	$rs1=$obj->showCountry();
	$ses=$obj->showSession();
	$res1=$ses->fetch_object();
	//$res1->session;
	if(isset($_POST['submit'])){
	
     
     $obj->registeruser($_POST['loginid'],
     				$_POST['password']);
     			    			
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>register_user</title>
<?php include('metabootstrap.php'); //if we comment up this inclusion then every bootstrap properties will be gone. i.e it will be a raw HTML page
    ?>
</head>

<body class="body">
<form method="post" >
	<div id="wrapper">
	<?php include('leftbar.php');?>


		<div id="page-wrapper">
			<div class="row">
				<div class="col-lg-12">
					<h4 class="page-header"> <?php echo strtoupper("welcome"." ".htmlentities($_SESSION['login']));?></h4>
				</div>
				<!-- /.col-lg-12 -->
			</div>
			<!-- /.row -->
			<div class="row">
			<div class="col-lg-12">
			<div class="panel panel-default">
			<div class="panel-heading">Register New User</div>
			<div class="panel-body">
			<div class="row">
			<div class="col-lg-10">
			<div class="form-group">
		    <div class="col-lg-4">
			<label>New User ID<span id="" style="font-size:11px;color:red">*</span>	</label>
			</div>
			
			<div class="col-lg-4">
			<input class="form-control" name="loginid" autofocus="select" required="required" pattern="[A-Za-z]+$">
			</div>
			</div>	
										
								<br><br>
								
		<div class="form-group">
		    <div class="col-lg-4">
			<label>New Password:<span id="" style="font-size:11px;color:red">*</span>	</label>
			</div>
			<div class="col-lg-4">
			<input class="form-control" name="password" required="required" pattern="[A-Za-z]+$">
			</div>
										
								<br><br>

	<br><br>		
		
									
													
				</div>

					</div>
								
							</div>
							
						</div>
						
					</div>
			



	<div class="form-group">
	<div class="col-lg-4">
	</div>
	<div class="col-lg-6">
	<input type="submit" class="btn btn-primary" name="submit" value="Register"></button>
	</div>
	</div>			
	</div>
	</div><!--row!-->		
	</div>	
			</div>
		</div>
	</div>
	</form>

	<!-- jQuery -->
	<?php include('jQuery1.php'); //including all files required for jquery and javascript needed in live search of elements present in the window 
    ?>



</body>

</html>
