<?php
session_start ();

if (! (isset ( $_SESSION ['login'] ))) {
	
	header ( 'location:loginstu.php' );
} 
   
    include('../config/DbFunction2.php');
    $obj=new DbFunction2();
	$rs=$obj->showDepartment();

?> 

<!DOCTYPE html>
<html lang="en">

<head>

    <?php include('metabootstrap.php'); //if we comment up this inclusion then every bootstrap properties will be gone. i.e it will be a raw HTML page
    ?>  

    <title>view department</title>

    <!-- Bootstrap Core CSS -->
    
    

</head>
<body class="body">

    <div id="wrapper">

        <!-- Navigation -->
      
      <?php include('leftbar2.php');?>

           
         <nav>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                   <h4 class="page-header"> <?php echo strtoupper("welcome"." ".htmlentities($_SESSION['login']));?></h4>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            View Department
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>S No</th>
                                            <th>Short Name</th>
                                            <th>Full Name</th>
                                            <th>HOD</th>
                                            <th>Course</th>
                                            <th>Created Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php 
                                         $sn=1;
                                     while($res=$rs->fetch_object()){?>	
                                        <tr class="odd gradeX">
                                           <td><?php echo $sn?></td>
                                            <td><?php echo htmlentities( strtoupper($res->dshort));?></td>
                                            <td><?php echo htmlentities( strtoupper($res->dfull));?></td>
                                            <td><?php echo htmlentities(strtoupper($res->dhead));?></td>
                                             <td><?php echo htmlentities(strtoupper($res->cshort));?></td>
                                             <td><?php echo htmlentities($res->ddate);?></td>
                                           
                                            
                                        </tr>
                                        
                                    <?php $sn++;}?>   	           
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
           
            
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
<?php include('jQuery1.php'); //including all files required for jquery and javascript needed in live search of elements present in the window 
 ?>

</body>

</html>
