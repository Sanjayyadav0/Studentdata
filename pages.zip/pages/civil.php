<?php include('../inc/navbar2.php'); ?>
<div class="w3-content" style="max-width:2000px; margin-top:16px">

  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">

  <h2 class="w3-wide">CIVIL ENGINEERING</h2>
    <p class="w3-opacity"><i>School Of Engineering And Technology</i></p>
    <p class="w3-opacity"><i>Bachelor Of Technology - B.Tech</i></p>
    <p class="w3-justify">This School was set up in 2007. There are five Departments under this School namely, the Department of Information Technology (IT), Department of Electronics & Communication Engineering (ECE), Department of Electrical Engineering (EE), Department of Computer Engineering (CE) and Department of Civil Engineering. B. Tech programme in IT and ECE commenced from August 2007 and August, 2008 respectively whereas B. Tech programme in the other two disciplines i.e. Electrical Engineering (EE) and Computer Engineering (CE) commenced from August, 2012.<br><br>

Engineering College Hostel for Boys and Girls are expected to be functional within the year 2013.<br><br>

Intake capacity in each B. Tech programme is 30. Admission for 50% of the available seats in each programme is through Central Counseling Board from AIEEE merit list whereas remaining seats are filled through the Mizoram University Engineering Entrance Examination (MZUEEE).
</p>
    
 <div class="w3-container w3-padding-32" id="projects">
    <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">Bachelor Courses</h3>
  </div>

  <div class="w3-row-padding">
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-display-container">
        <div class="w3-display-topleft w3-black w3-padding">Civil Engineering</div>
        <img src="../mee.jpg" alt="House" style="width:100%">
      </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-display-container">
        <div class="w3-display-topleft w3-black w3-padding">Computer Engineering</div>
        <img src="../mee.jpg" alt="House" style="width:100%">
      </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-display-container">
        <div class="w3-display-topleft w3-black w3-padding">Electical Engineering</div>
        <img src="../mee.jpg" alt="House" style="width:100%">
      </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-display-container">
        <div class="w3-display-topleft w3-black w3-padding">Electronics And Communication Engineering</div>
        <img src="../mee.jpg" alt="House" style="width:100%">
      </div>
    </div>
  </div>



  <!-- About Section -->
  <div class="w3-container w3-padding-32" id="about">
    <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">About</h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint
      occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
      laboris nisi ut aliquip ex ea commodo consequat.
    </p>
  </div>

  <div class="w3-row-padding w3-grayscale">
    <div class="w3-col l3 m6 w3-margin-bottom">
      <img src="../mee.jpg" alt="John" style="width:100%">
      <h3>John Doe</h3>
      <p class="w3-opacity">CEO & Founder</p>
      <p>Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>
      <p><button class="w3-button w3-light-grey w3-block">Contact</button></p>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <img src="../mee.jpg" alt="Jane" style="width:100%">
      <h3>Jane Doe</h3>
      <p class="w3-opacity">Architect</p>
      <p>Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>
      <p><button class="w3-button w3-light-grey w3-block">Contact</button></p>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <img src="../mee.jpg" alt="Mike" style="width:100%">
      <h3>Mike Ross</h3>
      <p class="w3-opacity">Architect</p>
      <p>Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>
      <p><button class="w3-button w3-light-grey w3-block">Contact</button></p>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <img src="../mee.jpg" alt="Dan" style="width:100%">
      <h3>Dan Star</h3>
      <p class="w3-opacity">Architect</p>
      <p>Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>
      <p><button class="w3-button w3-light-grey w3-block">Contact</button></p>
    </div>
  </div>




  </div>

</div> 
    


<?php include('footer.php'); ?>   

</body>

</html>
