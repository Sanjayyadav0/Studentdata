<?php
session_start ();
if (! (isset ( $_SESSION ['login'] ))) {
	header ( 'location:../index.php' );
}
  include('../config/DbFunction.php');
  $db=mysqli_connect('localhost','root','','project');
    
  if(!$db)
  {
    echo "connection error";
    exit;
  }
  else
  {
    $sql1 = "SELECT * FROM student";       //For the dashboard part
    $sql2 = "SELECT * FROM course";
    $sql3 = "SELECT * FROM department";
    $sql4 = "SELECT * FROM student WHERE scholarship='YES'";  

    $result1=mysqli_query($db,$sql1);
    $rowcount1=mysqli_num_rows($result1);

    $result2=mysqli_query($db,$sql2);
    $rowcount2=mysqli_num_rows($result2);

    $result3=mysqli_query($db,$sql3);
    $rowcount3=mysqli_num_rows($result3);  

    $result4=mysqli_query($db,$sql4);
    $rowcount4=mysqli_num_rows($result4);  
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
<style type="text/css">
        }
        .custom1{         
            text-align: center;
        }
       
    </style>
    <title>home</title>
    <?php include('metabootstrap.php'); //if we comment up this inclusion then every bootstrap properties will be gone. i.e it will be a raw HTML page
    ?> 



    





</head>


<body class="body1">

	<?php include('leftbar.php');?>
	<div id="page-wrapper" >
			<!-- <div class="box box-success">
				<div class="col-lg-12" >
					<h4 class="page-header"> <?php echo strtoupper("welcome"." ".htmlentities($_SESSION['login']));?></h4>
				</div>
				
			</div>
      -->

       
  <section >
      <div class="row">
        <div class="col-lg-12">
          <!-- small box 
          <div class="small-box bg-blue">
           <img src="../mz.jpg" class="img-responsive img-thumbnail" alt="mzu-image" width="9060"> 
          </div> 
          -->


<!-- slide try-->


          <div class="w3-content w3-section">
  

  <img class="mySlides w3-animate-fading" src="../mz.jpg" style="width:100%">
  <img class="mySlides w3-animate-fading" src="../mz1.jpg" style="width:100%">

</div>


<!-- slide try-->

        </div>
       </div>
      <!-- /.box (chat box) -->
  </section>
 
          <!-- /.box (chat box) -->
      
			<section class="content">

      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php printf("%d",$rowcount1);?></h3>
              <p>Registered Students</p><br>
            </div>
            <div class="icon">
              <i class="icon ion-person-stalker"></i>
            </div>
            <a href="view.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php printf("%d",$rowcount2);?></h3>
              <p>Total Courses</p><br>
            </div>
            <div class="icon">
              <i class="icon ion-android-list"></i>
            </div>
            <a href="view-course.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php printf("%d",$rowcount3);?></h3>
              <p>Total Departments</p><br>
            </div>
            <div class="icon">
              <i class="icon ion-briefcase"></i>
            </div>
            <a href="view-department.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php printf("%d",$rowcount4);?></h3>
              <p>Students Applied for Scholarship</p>
            </div>
            <div class="icon">
              <i class="icon ion-briefcase"></i>
            </div>
            <a href="view-scholarship.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
      </div>
      <!-- /.box (chat box) -->
	</section>

<?php include('jQuery1.php'); //including all files required for jquery and javascript needed in live search of elements present in the window 
 ?>

 <!-- slide script -->
<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 6000);    
}
</script>

</body>
</html>