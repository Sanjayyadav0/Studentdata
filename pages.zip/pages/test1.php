<?php
session_start ();
if (! (isset ( $_SESSION ['login'] ))) {
  header ( 'location:../index.php' );
}
  include('../config/DbFunction.php');
  $db=mysqli_connect('localhost','root','','project');
    
  if(!$db)
  {
    echo "connection error";
    exit;
  }
  else
  {
    $sql1 = "SELECT * FROM student";       //For the dashboard part
    $sql2 = "SELECT * FROM course";
    $sql3 = "SELECT * FROM department";
    $sql4 = "SELECT * FROM student WHERE scholarship='YES'";  

    $result1=mysqli_query($db,$sql1);
    $rowcount1=mysqli_num_rows($result1);

    $result2=mysqli_query($db,$sql2);
    $rowcount2=mysqli_num_rows($result2);

    $result3=mysqli_query($db,$sql3);
    $rowcount3=mysqli_num_rows($result3);  

    $result4=mysqli_query($db,$sql4);
    $rowcount4=mysqli_num_rows($result4);  
  }

?>

<?php include('../inc/navbar2.php'); ?>

<?php include('../inc/slide2.php'); ?>
<div class="w3-content" style="max-width:2000px">

   <div class="w3-container w3-content w3-center w3-padding-32" style="max-width:800px" id="band">

    <h3>Mizoram University</h3>
  <p><em>School Of Engineering And Technology</em></p>
  <p class="w3-justify">

    <?php include('../inc/dean.php'); ?>


    </p>
    

    <div class="w3-row w3-padding-32">
      


    </div>


  </div>
  </div>





  
</div> 
<?php include('footer.php'); ?>
