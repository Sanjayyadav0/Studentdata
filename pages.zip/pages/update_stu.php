<?php

session_start ();

if (! (isset ( $_SESSION ['login'] ))) {
	
	header ( 'location:../index.php' );
}
include('../config/DbFunction.php');
	$obj=new DbFunction();
	$id=$_GET['id'];
    $rs=$obj->showStudents1($id);
    $res=$rs->fetch_object(); 
	$c=$res->cshort;
    $cname=$obj->showCourse1($c);
    $res1=$cname->fetch_object();
	$rs1=$obj->showCourse();
	$rs2=$obj->showCountry();
	if(isset($_POST['submit'])){
	
     
    $obj->edit_std(	$_POST['fname'],
     				$_POST['mname'],
     				$_POST['lname'],
     	            $_POST['gender'],
     	            $_POST['gname'],
     	            $_POST['ocp'],
     	            $_POST['income'],
     	            $_POST['category'],
     	            $_POST['ph'],
     	            $_POST['nation'],
     	            $_POST['mobno'],
     	            $_POST['email'],
     	            $_POST['padd'],
 	  	            $_POST['cadd'],
 	  	            $_POST['board1'],
 	  	            $_POST['board2'],
 	  	            $_POST['roll1'],
 	  	            $_POST['roll2'],
 	  	            $_POST['pyear1'],
     	            $_POST['pyear2'],
     	            $_GET['id']);

	
}
?>
<?php include('../inc/navbar2.php'); ?>

<div class="w3-content" style="max-width:2000px; margin-top:16px">



  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">

                <h2 class="w3-wide">Registration Form</h2>
    <p class="w3-opacity"><i>School Of Engineering And Technology</i></p>


    <form method="post" >
    <div id="wrapper">
    
     

        <div id="page-wrapper">
            
            <!-- /.row -->
            <div class="row">
            <div class="col-lg-12">
            
            <div class="row">
            <div class="col-lg-12">
            <div class="panel panel-default">
            <div class="panel-heading">Update Personal Informations</div>
            <div class="panel-body">
            <div class="row">
            <div class="col-lg-12">
            <div class="form-group">
            <div class="col-lg-2">
            <label>First Name<span id="" style="font-size:11px;color:red">*</span>  </label>
            
            </div>
            <div class="col-lg-4">
            <input class="form-control" name="fname" value="<?php echo htmlentities($res->fname);?>"required="required">
            </div>
             <div class="col-lg-2">
            <label>Middle Name</label>
            
            </div>
            <div class="col-lg-4">
            <input class="form-control" name="mname" value="<?php echo htmlentities($res->mname);?>">
            </div>
            </div>  
            <br><br>
                                
        <div class="form-group">
            <div class="col-lg-2">
            <label>Last Name</label>
            </div>
            <div class="col-lg-4">
            <input class="form-control" name="lname" value="<?php echo htmlentities($res->lname);?>">
            </div>
             <div class="col-lg-2">
            <label>Gender<span id="" style="font-size:11px;color:red">*</span></label>
            
            </div>
            <div class="col-lg-4">
            <?php 
            if (strcasecmp($res->gender,"Male")==0){?>
         <input type="radio" name="gender" id="male" value="Male" required="required" checked> &nbsp; Male &nbsp;
         <?php }else{ ?>
         <input type="radio" name="gender" id="male" value="Male" required="required"> &nbsp; Male &nbsp;
         <?php }?>
         <?php 
            if (strcasecmp($res->gender,"female")==0){?>
         <input type="radio" name="gender" id="female" value="female" checked> &nbsp; Female &nbsp;
         <?php } else{?>
         <input type="radio" name="gender" id="female" value="female"> &nbsp; Female &nbsp;
         <?php }?>
         <?php 
            if (strcasecmp($res->gender,"other")==0){?>
         <input type="radio" name="gender" id="other" value="other" checked> &nbsp; Other &nbsp;
         <?php } else{?>
         <input type="radio" name="gender" id="other" value="other"> &nbsp; Other &nbsp;
         <?php }?>
            </div>
            </div>  
    <br><br>        
             <div class="form-group">
             <div class="col-lg-2">
            <label>Guardian Name<span id="" style="font-size:11px;color:red">*</span>   </label>
            
            </div>
            <div class="col-lg-4">
            <input class="form-control" name="gname" required="required" 
            value="<?php echo htmlentities($res->gname);?>">
            </div>
             <div class="col-lg-2">
            <label>Occupation</label>
            
            </div>
            <div class="col-lg-4">
            <input class="form-control" name="ocp" id="ocp" value="<?php echo htmlentities($res->ocp);?>">
            </div>
            </div>  
            <br><br>
                    
             <div class="form-group">
             <div class="col-lg-2">
            <label>Family Income<span id="" style="font-size:11px;color:red">*</span></label>
            
            </div>
            <div class="col-lg-4">
            <select class="form-control" name="income"  id="income"required="required" >
        <option value="<?php echo htmlentities($res->income);?>"><?php echo htmlentities($res->income);?></option>
        <option VALUE="200000">200000</option>
        <option value="500000">500000</option>
        <option value="700000">700000</option>
        
       </select>
            </div>
             <div class="col-lg-2">
            <label>Category<span id="" style="font-size:11px;color:red">*</span></label>
            
            </div>
            <div class="col-lg-4">
            <select class="form-control" name="category"  id="category" required="required" >
        <option value="<?php echo htmlentities(strtoupper($res->category));?>"><?php echo htmlentities(strtoupper($res->category));?></option>
        <option VALUE="general">General</option>
        <option value="obc">OBC</option>
        <option value="sc">SC</option>
        <option value="st">ST</option>
        <option value="other">Other</option>
       </select>
            </div>
            </div>  
            <br><br>
            
            
                    
             <div class="form-group">
             <div class="col-lg-2">
            <label>Physically Challenged<span id="" style="font-size:11px;color:red">*</span></label>
            
            </div>
            <div class="col-lg-4">
            <select class="form-control" name="ph"  id="ph"required="required" >
        <option VALUE="<?php echo htmlentities(strtoupper($res->pchal));?>"><?php echo htmlentities(strtoupper($res->pchal));?></option>
        <option VALUE="yes">Yes</option>
        <option value="no">No</option>
               
       </select>
            </div>
             <div class="col-lg-2">
            <label>Nationality<span id="" style="font-size:11px;color:red">*</span></label>
            
            </div>
            <div class="col-lg-4">
            <input class="form-control" name="nation" id="nation" required="required" 
            value="<?php echo htmlentities($res->nationality);?>">
            </div>
            </div>  
            <br><br>
            </div>  
            <br><br>
        </div>
        </div>
        </div>
            
        <div class="row">
            <div class="col-lg-12">
            <div class="panel panel-default">
            <div class="panel-heading">Contact Informations</div>
            <div class="panel-body">
            <div class="row">
            <div class="col-lg-12">
            <div class="form-group">
            <div class="col-lg-2">
            <label>Mobile Number<span id="" style="font-size:11px;color:red">*</span>   </label>
            
            </div>
            <div class="col-lg-4">
            <input class="form-control" type="number" name="mobno" required="required" maxlength="10" 
               value="<?php echo htmlentities($res->mobno);?>">
            </div>
             <div class="col-lg-2">
            <label>Email Id<span id="" style="font-size:11px;color:red">*</span></label>
            
            </div>
            <div class="col-lg-4">
            <input class="form-control"  type="email" name="email" required="required" 
            value="<?php echo htmlentities($res->emailid);?>">
            </div>
            </div>  
            <br><br>
                                
            
            
    <br><br>        
             <div class="form-group">
             
            
             <div class="col-lg-2">
            <label>Permanent Address<span id="" style="font-size:11px;color:red">*</span></label>
            
            </div>
            <div class="col-lg-4">
            <textarea class="form-control" rows="3" name="padd"><?php echo htmlentities($res->padd);?></textarea>
            </div>
            </div>  
            <br><br><br><br>
                    
             
            <br><br>
            
            
                    
             <div class="form-group">
             <div class="col-lg-2">
            <label>Correspondence Address<span id="" style="font-size:11px;color:red">*</span>
            </label>
            </div>
            <div class="col-lg-4">
      <textarea class="form-control" rows="3" name="cadd"><?php echo htmlentities($res->cadd);?></textarea>
            </div>
             <div class="col-lg-2">
            
            
            
            </div>
            <div class="col-lg-4">
            
            </div>
            </div>  
            <br><br>
            
            
            </div>  
            <br><br>
        </div>
        </div>
        </div>                  
        <div class="row">
            <div class="col-lg-12">
            <div class="panel panel-default">
            <div class="panel-heading">Academic Informations</div>
            <div class="panel-body">
            <div class="row">
            
            <div class="col-lg-12">
            <div class="form-group">
            <div class="panel panel-default">
            <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                         <div class="col-lg-6">
            <th>&nbsp;&nbsp;&nbsp;&nbsp;Board<span id="" style="font-size:11px;color:red">*</span>  </label></th>
            </div>   
            <div class="col-lg-6">
            <th>&nbsp;&nbsp;&nbsp;&nbsp;Roll No</th>
            </div>   
              <div class="col-lg-6">
             <th>&nbsp;&nbsp;&nbsp;&nbsp;Year Of Passing<span id="" style="font-size:11px;color:red">*</span></th>
            </div>                                 
            </tr>
                                    </thead>
                                    <tbody>
                                        <tr> 
                  <td><div class="col-lg-6">
                  <input class="form-control" type="text" name="board1" value="<?php echo htmlentities($res->board);?>">
                  </div></td>
                  <td><div class="col-lg-6">
            <input class="form-control" type="text" name="roll1" value="<?php echo htmlentities($res->roll);?>">
            </div></td>
            <td><div class="col-lg-6">
            <input class="form-control"  type="text" name="pyear1" value="<?php echo htmlentities($res->pyear);?>">
            </div></td>
                  </tr>

              <tr> 
                  <td><div class="col-lg-6">
                  <input class="form-control" type="text" name="board2" value="<?php echo htmlentities($res->board1);?>">
                  </div></td>
                  <td><div class="col-lg-6">
            <input class="form-control" type="text" name="roll2" value="<?php echo htmlentities($res->roll1);?>">
            </div></td>
            <td><div class="col-lg-6">
            <input class="form-control"  type="text" name="pyear2" value="<?php echo htmlentities($res->yop1);?>">
            </div></td>
                  </tr>      
                                        
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
            </div>  
            <br><br>                    
          </div>    
            <br><br>            
            <br><br>
            
            <br>
        
    


    <div class="form-group">
    
    <div align="center">
    <button type="submit" class="btn btn-lg btn-info" name="submit" value="Upadate">Update</button>    
    </div>
    </div>      
    
    </div>          
    </div>
    </div><!--row!-->   

                    
                </div>
                
            </div>
            
        </div>
        

    </div>
    

  
    
    <script>
function showState(val) {
    
    $.ajax({
    type: "POST",
    url: "subject.php",
    data:'id='+val,
    success: function(data){
      // alert(data);
        $("#state").html(data);
    }
    });
}

function showDist(val) {
    
    $.ajax({
    type: "POST",
    url: "subject.php",
    data:'did='+val,
    success: function(data){
      // alert(data);
        $("#dist").html(data);
    }
    });
    
}



                            //AJAX
function showSub(val) {
    
    //alert(val);
    $.ajax({
    type: "POST",
    url: "subject.php",
    data:'cid='+val,
    success: function(data){
      // alert(data);
        $("#c-full").val(data);
    }
    });
    
}
</script>
</form></div></div></div></div></div></div></form></div></div>
<?php include('footer.php'); ?>
</body>

</html>
