<?php
session_start ();
if (! (isset ( $_SESSION ['login'] ))) {
		header ( 'location:../index.php' );
} 
    include('../config/DbFunction.php');
    $obj=new DbFunction();
	$rs=$obj->showScholarshipDetails();

	if(isset($_GET['del']))
    {
          $obj->del_course(intval($_GET['del']));
  }
?> 


<?php include('../inc/navbar.php'); ?>

<div class="w3-content" style="max-width:2000px; margin-top:46px">

  <div class="w3-container w3-content w3-center " style="max-width:800px" id="band">       
        <h2 class="w3-wide">View Students Availing Scholarship</h2>
    <p class="w3-opacity"><i>School Of Engineering And Technology</i></p>
        <div id="page-wrapper">
                
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            View Scholarship Details
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>S No</th>
                                            <th>Scholarship Scheme</th>
                                            <th>Name</th>
                                            <th>Department Name</th>
                                            
                                            
                                            <th>Session</th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php 
                                         $sn=1;
                                     while($res=$rs->fetch_object()){?>	
                                        <tr class="odd gradeX">
                                            <td><?php echo $sn?></td>
                                             <td><?php echo htmlentities(strtoupper($res->category));?></td>
                                            
                                            <td><?php echo htmlentities(strtoupper($res->fname." ".$res->mname." ".$res->lname));?></td>
                                           <td><?php echo htmlentities(strtoupper($res->cshort));?></td>
                                              <td><?php echo htmlentities($res->session);?></td>
                                            
                                            
                                        </tr>
                                        
                                    <?php $sn++;}?>   	           
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
           
            
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    <?php include('jQuery1.php'); //including all files required for jquery and javascript needed in live search of elements present in the window 
    ?>
   <?php include('footer.php'); ?>
</body>

</html>
