<?php
session_start ();

if (! (isset ( $_SESSION ['login'] ))) {
	
	header ( 'location:../index.php' );
}
include('../config/DbFunction.php');
	$obj=new DbFunction();

	
	$rs=$obj->showCourse();
	$rs1=$obj->showCountry();
	$rs2=$obj->showExam();
	$ses=$obj->showSession();
	$res1=$ses->fetch_object();
	//$res1->session;
	if(isset($_POST['submit'])){
		extract($_POST);
		$mob="/^[1-9][0-9]*$/";
		if(!preg_match($mob, $mobno)) 
    $msg="Please enter a valid number";

     
     $obj->register($_POST['app_type'],
     				$_POST['exam_id'],
     				$_POST['course-short'],
     				$_POST['department-short'],
     				$_POST['fname'],
     				$_POST['mname'],
     				$_POST['lname'],
     				$_POST['dob'],
     				$_POST['gender'],
     	            $_POST['gname'],
     	            $_POST['category'],
     	            $_POST['religion'],
     	            $_POST['ph'],
     	            $_POST['nation'], 
     	            $_POST['mobno'],
     	            $_POST['gmobno'],
     	            $_POST['email'],
     	            $_POST['country'],
     	            $_POST['state'],
     	            $_POST['dist'],
     	            $_POST['padd'],
     	            $_POST['cadd'],
     	            $_POST['x_board'],
     	            $_POST['xii_board'],
     	            $_POST['x_percent'],
     	            $_POST['xii_percent'],
     	            $_POST['x_pyear'],
     	            $_POST['xii_pyear'],
     	            $_POST['session']);
     	            
     	            

	
}
?>


<?php include('../inc/navbar2.php'); ?>

<div class="w3-content" style="max-width:2000px; margin-top:16px">



  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">

				<h2 class="w3-wide">Registration Form</h2>
    <p class="w3-opacity"><i>School Of Engineering And Technology</i></p>
   
    

		<form method="post" >
			<div id="wrapper">
	


		<div id="page-wrapper">
			
			<!-- /.row -->
			<div class="row">
			<div class="col-lg-14">
			<div class="panel panel-default">
			<div class="panel-heading" style="background-color: teal; color: white ">Program Informations</div>
			
			<div class="panel-body">
			<div class="row">
			<div class="col-lg-10">

<div class="form-group">
		    <div class="col-lg-4">
			<label>Application Type<span id="" style="font-size:11px;color:red">*</span>	</label>
			</div>
			<div class="col-lg-6">
<select class="form-control" name="app_type"  id="app_type"required="required" >
        <option VALUE="" disabled selected>Select Type </option>
        <option VALUE="Regular">Regular</option>
        <option value="Lateral Entry">Lateral Entry</option>
        
        
       </select>
										</div>
											
										</div>	
										
								<br><br>




			<div class="form-group">
		    <div class="col-lg-4">
			<label>Applying Through<span id="" style="font-size:11px;color:red">*</span>	</label>
			</div>
			<div class="col-lg-6">
<select class="form-control" name="exam_id" id="exam_id" onchange="showState(this.value)" required="required" >			

<option VALUE="" disabled selected>Select Exam</option>
				<?php while($res=$rs2->fetch_object()){?>							
			
   <option VALUE="<?php echo htmlentities($res->id);?>"><?php echo htmlentities($res->exam_shortname)?></option>
                        
                        
                    <?php }?>   </select>
										</div>
											
										</div>	
										
								<br><br>




			<div class="form-group">
		    <div class="col-lg-4">
			<label>Select Program<span id="" style="font-size:11px;color:red">*</span>	</label>
			</div>
			<div class="col-lg-6">
<select class="form-control courseSelect"  autofocus="select" name="course-short" id="cshort"  required="required" >			
<option VALUE="">Select Program</option>
				<?php while($res=$rs->fetch_object()){?>							
			
                        <option VALUE="<?php echo htmlentities($res->cshort);?>"><?php echo htmlentities($res->cshort)?></option>
                        
                        
                    <?php }?>   </select>
										</div>
											
										</div>	
										
								<br><br>
								
		<div class="form-group">
		    <div class="col-lg-4">
			<label>Select Department<span id="" style="font-size:11px;color:red">*</span>	</label>
			</div>
			<div class="col-lg-6">
<select class="form-control deptSelect" name="department-short" id="dshort"  required="required" >			
<option VALUE="">Select Department</option>
				  </select>
										</div>
											
										</div>	
										
								<br><br>





			<div class="form-group">
		<div class="col-lg-4">
		<label>Current  Session<span id="" style="font-size:11px;color:red">*</span></label>
		</div>
		<div class="col-lg-6">
		
	   <input class="form-control" name="session" value="<?php echo htmlentities($res1->session);?>" readonly>
	 </div>	
										
	 <br><br>								
	
	</div>	
	<br><br>		
		
									
													
				</div>

					</div>
								
							</div>
							
						</div>
						
					</div>



			<div class="row">
			<div class="col-lg-12">
			<div class="panel panel-default">
			<div class="panel-heading" style="background-color: teal; color: white ">Personal Informations</div>
			<div class="panel-body">
			<div class="row">
			<div class="col-lg-12">
			<div class="form-group">
		    <div class="col-lg-2">
			<label>First Name<span id="" style="font-size:11px;color:red">*</span>	</label>
			
			</div>
			<div class="col-lg-4">
			<input class="form-control" name="fname" required="required"  autocomplete="off" pattern="[A-Za-z]+$">
			</div>
			 <div class="col-lg-2">
			<label>Middle Name</label>
			
			</div>
			<div class="col-lg-4">
			<input class="form-control" name="mname"  autocomplete="off" pattern="[A-Za-z]+$">
			</div>
			</div>	
			<br><br>
								
		<div class="form-group">
		    <div class="col-lg-2">
			<label>Last Name<span id="" style="font-size:11px;color:red">*</span></label>
			</div>
			<div class="col-lg-4">
			<input class="form-control" name="lname" required="required" autocomplete="off" pattern="[A-Za-z]+$">
			</div>
			 <div class="col-lg-2">
			<label>Gender</label>
			
			</div>
			<div class="col-lg-4" >
		 <input type="radio" name="gender" required="required" id="male" value="Male"> &nbsp; Male &nbsp;
		 <input type="radio" name="gender" required="required" id="female" value="feale"> &nbsp; Female &nbsp;
		 <input type="radio" name="gender" required="required" id="other" value="other"> &nbsp; Other &nbsp;
			</div>
			</div>	
	<br><br>		
		     <div class="form-group">
		     <div class="col-lg-2">
			<label>Date of Birth<span id="" style="font-size:11px;color:red">*</span></label>
			
			</div>
			<div class="col-lg-4">
			<input class="form-control" id="dob" name="dob" placeholder="MM/DD/YYY" type="date" required="required">
			</div>
			 <div class="col-lg-2">
			<label>Guardian Name<span id="" style="font-size:11px;color:red">*</span>	</label>
			
			</div>
			<div class="col-lg-4">
			<input class="form-control" name="gname"  autocomplete="off" required="required">
			</div>
			
			</div>	
			<br><br>
					
		     <div class="form-group">
			 <div class="col-lg-2">
			<label>Religion<span id="" style="font-size:11px;color:red">*</span></label>
			
			</div>
			<div class="col-lg-4">
			<input class="form-control" name="religion" id="religion" autocomplete="off" required="required">
			</div>
			 <div class="col-lg-2">
			<label>Category<span id="" style="font-size:11px;color:red">*</span></label>
			
			</div>
			<div class="col-lg-4">
			<select class="form-control" name="category"  id="category" required="required" >
        <option VALUE="">Select Category</option>
        <option VALUE="general">General</option>
        <option value="obc">OBC</option>
        <option value="sc">SC</option>
        <option value="st">ST</option>
		<option value="other">Other</option>
       </select>
			</div>
			</div>	
			<br><br>
			
			
					
		     <div class="form-group">
			 <div class="col-lg-2">
			<label>Physically Challenged<span id="" style="font-size:11px;color:red">*</span></label>
			
			</div>
			<div class="col-lg-4">
			<select class="form-control" name="ph"  id="ph"required="required" >
        <option VALUE="">Select If Any</option>
        <option VALUE="yes">Yes</option>
        <option value="no">No</option>
               
       </select>
			</div>
			 <div class="col-lg-2">
			<label>Nationality<span id="" style="font-size:11px;color:red">*</span></label>
			
			</div>
			<div class="col-lg-4">
			<input class="form-control"  autocomplete="off" required="required" name="nation" id="nation">
			</div>
			</div>	
			<br><br>
			</div>	
			<br><br>
		</div>
      	</div>
		</div>
			
		<div class="row">
			<div class="col-lg-12">
			<div class="panel panel-default">
			<div class="panel-heading" style="background-color: teal; color: white ">Contact Informations</div>
			<div class="panel-body">
			<div class="row">
			<div class="col-lg-12">
			<div class="form-group">
		    <div class="col-lg-2">
			<label>Mobile Number<span id="" style="font-size:11px;color:red">*</span>	</label>
			
			</div>
			<div class="col-lg-4">
			<input class="form-control" type="number" name="mobno" required="required" pattern="[0-9]{10}$">
			</div>
			 <div class="col-lg-2">
			<label>Email Id<span id="" style="font-size:11px;color:red">*</span></label>
			
			</div>
			<div class="col-lg-4">
			<input class="form-control"  type="email" placeholder="abc@gmail.com" required="required" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" name="email">
			</div>
			</div>	
			<br><br>
								
		<div class="form-group">
		<div class="col-lg-2">
			 <label>Guardian Mobile Number<span id="" style="font-size:11px;color:red">*</span>	</label>
			
			</div>
			<div class="col-lg-4">
			<input class="form-control" type="number" name="gmobno" id="gmobno" required="required" pattern="[0-9]{10}$">
			</div>

		    <div class="col-lg-2">
			<label>Country<span id="" style="font-size:11px;color:red">*</span></label>
			</div>
			<div class="col-lg-4">
			<select class="form-control" name="country" id="country" onchange="showState(this.value)" required="required" >			

<option VALUE="">Select Country</option>
				<?php while($res=$rs1->fetch_object()){?>							
			
   <option VALUE="<?php echo htmlentities($res->id);?>"><?php echo htmlentities($res->name)?></option>
                        
                        
                    <?php }?>   </select>
			</div>
			 
			
			</div>	
			
	<br><br>		
		     <div class="form-group">
		     <div class="col-lg-2">
			<label>State<span id="" style="font-size:11px;color:red">*</span></label>
			
			</div>
			<div class="col-lg-4">
 <select name="state" id="state"  class="form-control" onchange="showDist(this.value)" required="required">
        <option value="">Select State</option>
        </select>
			</div>

			 <div class="col-lg-2">
			<label>City<span id="" style="font-size:11px;color:red">*</span>	</label>
			
			</div>
			<div class="col-lg-4">
           <select name="dist" id="dist"  class="form-control" onchange="" required="required">
        <option value="">Select City</option>
		</select>
			</div>
			 
			
			</div>	
			<br><br>
			
			
					
		     <div class="form-group">
		     <div class="col-lg-2">
				<label>Permanent Address<span id="" style="font-size:11px;color:red">*</span></label>
			
			</div>
			<div class="col-lg-4">
			<textarea class="form-control" rows="3" name="padd" required="required" id="padd"></textarea>
			</div>

			 <div class="col-lg-2">
			<label>Correspondence Address<span id="" style="font-size:11px;color:red">*</span>
			
			</div>
			<div class="col-lg-4">
      <textarea class="form-control" rows="3" name="cadd"  required="required" id="cadd"></textarea>
			</div>

			 
			
			
			
			</div>
			<div class="col-lg-4">
			
			</div>
			</div>	
			<br><br>
			
			
			</div>	
			<br><br>
		</div>
      	</div>
		</div>					


		</div>





        <div class="row">
			<div class="col-lg-12">
			<div class="panel panel-default">
			<div class="panel-heading" style="background-color: teal; color: white ">Academic Informations</div>
			<div class="panel-body">
			<div class="row">
			
			<div class="col-lg-12">
			<div class="form-group">
		    <div class="panel panel-default">
            <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                         <div class="col-lg-6">
			<th>&nbsp;&nbsp;&nbsp;&nbsp;Board Name<span id="" style="font-size:11px;color:red">*</span>	</label></th>
			</div>   
            <div class="col-lg-6">
			<th>&nbsp;&nbsp;&nbsp;&nbsp;Roll Number<span id="" style="font-size:11px;color:red">*</span></th>
			</div>   
              <div class="col-lg-6">
			 <th>&nbsp;&nbsp;&nbsp;&nbsp;Year Of Passing<span id="" style="font-size:11px;color:red">*</span></th>
			</div>                                 
            </tr>
                                    </thead>
                                    <tbody>
                                        <tr> 
                  <td><div class="col-lg-6">
				  <input class="form-control" type="text" required="required" name="x_board">
				  </div></td>
                  <td><div class="col-lg-6">
			<input class="form-control" type="text" required="required" name="x_percent" >
			</div></td>
            <td><div class="col-lg-6">
			<input class="form-control"  type="Year" required="required" name="x_pyear" >
			</div></td>
                  </tr>

              <tr> 
                  <td><div class="col-lg-6">
				  <input class="form-control" type="text" required="required" name="xii_board" >
				  </div></td>
                  <td><div class="col-lg-6">
			<input class="form-control" type="text" required="required" name="xii_percent" >
			</div></td>
            <td><div class="col-lg-6">
			<input class="form-control"  type="Year" required="required" name="xii_pyear" >
			</div></td>
                  </tr>      
                                        
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
			</div>	
			<br><br>					
		  </div>	
			<br><br>			
			<br><br>
				
			<br>
		
	<div class="form-group">
	
	<div align="center">
	<button type="submit" class="btn btn-lg btn-info" name="submit" value="Register">Submit</button>	
	</div>
	</div>			
	</div>
	</div><!--row!-->		
	</div>	
			</div>
		</div>
	</div>
	</form>

	<!-- jQuery -->
		<?php include('jQuery1.php'); //including all files required for jquery and javascript needed in live search of elements present in the window 
        ?>
	
	<script>
function showState(val) {
    
  	$.ajax({
	type: "POST",
	url: "subject.php",
	data:'id='+val,
	success: function(data){
	  // alert(data);
		$("#state").html(data);
	}
	});
}

function showDist(val) {
    
  	$.ajax({
	type: "POST",
	url: "subject.php",
	data:'did='+val,
	success: function(data){
	  // alert(data);
		$("#dist").html(data);
	}
	});
	
}


$('.courseSelect').change(function(){
	var courseName=$(this).val();
	// alert(courseName);
	$.post('fetchDepartment.php',{courseName:courseName},function(data){
		$('.deptSelect').html(data);
	});
});

function showSub(val) {
    
    //alert(val);
  	$.ajax({
	type: "POST",
	url: "subject.php",
	data:'cid='+val,
	success: function(data){
	  alert(data);
		//$("#c-full").val(data);
	}
	});
	
}



</script>

</label>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
</div>
</div>
</div></div></div>
</div></form></div></div>
<?php include('footer.php'); ?>
</body>

</html>
