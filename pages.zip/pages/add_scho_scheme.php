<?php
session_start ();

if (! (isset ( $_SESSION ['login'] ))) {
	
	header ( 'location:../index.php' );
}
include('../config/DbFunction.php');
	$obj=new DbFunction();

	$sch=$obj->showCategory();
	
	$rs=$obj->showCourse();
	$rs1=$obj->showCountry();
	$ses=$obj->showSession();
	$res1=$ses->fetch_object();

	//$res1->session;
	if(isset($_POST['submit'])){
	
     
     $obj->scholarship($_POST['fname']);
     	            
  	            
}
?>
<?php include('../inc/navbar2.php'); ?>

<div class="w3-content" style="max-width:2000px; margin-top:16px">



  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">

				<h2 class="w3-wide">Scholarship Details</h2>
    <p class="w3-opacity"><i>School Of Engineering And Technology</i></p>
<form method="post" >
	<div id="wrapper">



		<div id="page-wrapper">
			
			<!-- /.row -->
			<div class="row">
			<div class="col-lg-12">
			<div class="panel panel-default">
			<div class="panel-body">
			<div class="row">
			<div class="col-lg-10">
			<div class="form-group">
		    <div class="col-lg-4">
			<label>Select Scholarship Scheme<span id="" style="font-size:11px;color:red">*</span>	</label>
			</div>
			<div class="col-lg-6">
<select class="form-control categorySelect" name="category" id="category" autofocus="select" required="required" >			
<option VALUE="">SELECT SCHEME</option>
				<?php while($res=$sch->fetch_object()){?>							
			
                        <option VALUE="<?php echo htmlentities($res->category);?>"><?php echo htmlentities(strtoupper($res->category))?></option>
                        
                        
                    <?php }?>   </select>
			</div>
											
			</div>	
										
								<br><br>
								
		<div class="form-group">
		    <div class="col-lg-4">
			<label>Select Student<span id="" style="font-size:11px;color:red">*</span>	</label>
			</div>
			<div class="col-lg-6">
<select class="form-control nameSelect" name="fname" id="fname"  required="required" >			
<option VALUE="">SELECT STUDENT</option>
				  </select>
										</div>
											
										</div>	
										
								<br><br>

			<div class="form-group">
		<div class="col-lg-4">
		<label>Current  Session<span id="" style="font-size:11px;color:red">*</span></label>
		</div>
		<div class="col-lg-6">
		
	   <input class="form-control" name="session" value="<?php echo htmlentities($res1->session);?>" readonly>
	 </div>	
										
	 <br><br>								
	
	</div>	
	<br><br>		
		
									
													
				</div>

					</div>
								
							</div>
							
						</div>
						
					</div>
					
			<br><br>
				
			<br>
		
	<div class="form-group">
	<div class="col-lg-4">
	</div>
	<div class="col-lg-6">
	<input type="submit" class="btn btn-primary" name="submit" value="Submit"></button>
	</div>
	</div>			
	</div>
	</div><!--row!-->		
	</div>	
			</div>
		</div>
	</div>
	</form>

	<!-- jQuery -->

	
	<script>
function showState(val) {
    
  	$.ajax({
	type: "POST",
	url: "subject.php",
	data:'id='+val,
	success: function(data){
	  // alert(data);
		$("#state").html(data);
	}
	});
}

function showDist(val) {
    
  	$.ajax({
	type: "POST",
	url: "subject.php",
	data:'did='+val,
	success: function(data){
	  // alert(data);
		$("#dist").html(data);
	}
	});
	
}


$('.categorySelect').change(function(){
	var category=$(this).val();
	// alert(courseName);
	$.post('fetchName.php',{category:category},function(data){
		$('.nameSelect').html(data);
	});
});

$('.courseSelect').change(function(){
	var courseName=$(this).val();
	// alert(courseName);
	$.post('fetchDepartment.php',{courseName:courseName},function(data){
		$('.deptSelect').html(data);
	});
});

function showSub(val) {
    
    //alert(val);
  	$.ajax({
	type: "POST",
	url: "subject.php",
	data:'cid='+val,
	success: function(data){
	  alert(data);
		//$("#c-full").val(data);
	}
	});
	
}



</script>

</label>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
</div>
</div>
</div></div></div>
</div></form></div></div>
<?php include('footer.php'); ?>

</body>

</html>
