<?php
session_start ();
if (! (isset ( $_SESSION ['login'] ))) {
	header ( 'location:../index.php' );
} 
    include('../config/DbFunction.php');
    $obj=new DbFunction();
	$rs=$obj->showstudents();
   
   	if(isset($_GET['del']))
    {    
         $obj->del_std(intval($_GET['del']));
    }
?> 

<?php include('../inc/navbar2.php'); ?>


<div class="w3-content" style="max-width:2000px; margin-top:16px">


    <div class="w3-container w3-content w3-center w3-padding-64 " style="max-width:800px" id="band">       
        <h2 class="w3-wide">View Students</h2>
    <p class="w3-opacity"><i>School Of Engineering And Technology</i></p>


        <div id="page-wrapper">
           <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th style="text-align: left">SNo</th>
                                            <th style="text-align: left">RegNo</th>
                                            <th style="text-align: left">Name</th>
                                            
                                            <th style="text-align: left">Course</th>
                                            <th style="text-align: left">Department</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>

                                <?php 
                                         $sn=1;
                                     while($res=$rs->fetch_object()){
                                     
                                      $c=$res->cshort;
                                      $cname=$obj->showCourse1($c);
                                      $res1=$cname->fetch_object();
                                      
                                 ?> 
                                        <tr class="odd gradeX">
                                <td style="text-transform: uppercase; text-align: left"><?php echo $sn?></td>
                                <td style="text-transform: uppercase; text-align: left"><?php echo htmlentities( strtoupper($res->regno));?></td>
                                <td style="text-transform: uppercase; text-align: left"><?php echo htmlentities($res->fname." ".$res->mname." ".$res->lname);?></td>
                                
                                <td style="text-transform: uppercase; text-align: left"><?php echo htmlentities($res1->cshort);?></td>
                                <td style="text-transform: uppercase; text-align: left"><?php echo htmlentities(strtoupper($res->dshort));?></td>                                             
                                
                                            
                                        </tr>
                                        
                                    <?php $sn++;}  ?>                  
                                    </tbody>
                                </table>
            

  <br>
  <?php include('../inc/print_button.php'); ?>  

        </div>

    </div>
</div>
 <?php include('footer.php'); ?>
</body>
</html>
