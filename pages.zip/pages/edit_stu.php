<?php

session_start ();

if (! (isset ( $_SESSION ['login'] ))) {
	
	header ( 'location:../index.php' );
}
include('../config/DbFunction.php');
	$obj=new DbFunction();
	$id=$_GET['id'];
    $rs=$obj->showStudents1($id);
    $res=$rs->fetch_object(); 
	$c=$res->cshort;
    $cname=$obj->showCourse1($c);
    $res1=$cname->fetch_object();
	$rs1=$obj->showCourse();
	$rs2=$obj->showCountry();
	if(isset($_POST['submit'])){
	
     
    $obj->edit_std(	$_POST['fname'],
     				$_POST['mname'],
     				$_POST['lname'],
     	            $_POST['gender'],
     	            $_POST['gname'],
     	            $_POST['ocp'],
     	            $_POST['income'],
     	            $_POST['category'],
     	            $_POST['ph'],
     	            $_POST['nation'],
     	            $_POST['mobno'],
     	            $_POST['email'],
     	            $_POST['padd'],
 	  	            $_POST['cadd'],
 	  	            $_POST['board1'],
 	  	            $_POST['board2'],
 	  	            $_POST['roll1'],
 	  	            $_POST['roll2'],
 	  	            $_POST['pyear1'],
     	            $_POST['pyear2'],
     	            $_GET['id']);

	
}
?>

<?php include('../inc/navbar2.php'); ?>

<div class="w3-content" style="max-width:2000px; margin-top:16px">

  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">

  	<h2 class="w3-wide">Update Information</h2>
    <p class="w3-opacity"><i>School Of Engineering And Technology</i></p>


    <form method="post" >



<!-- Personal Information -->
				<div class="col-lg-12 well">
					<p class="w3-opacity w3-card" style=" font-size: 20px">Personal Information</p>
					<div class="row">
							<div class="col-sm-4 form-group">
								<label>First Name</label>
								<input class="form-control input-sm" name="fname" readonly value="<?php echo htmlentities($res->fname);?>"required="required">
							</div>
							<div class="col-sm-4 form-group">
								<label>Middle Name</label>
								<input class="form-control" name="mname" readonly pattern="[A-Za-z]+$" value="<?php echo htmlentities($res->mname);?>">
							</div>
							<div class="col-sm-4 form-group">
								<label>Last Name</label>
								<input class="form-control" name="lname" readonly pattern="[A-Za-z]+$" value="<?php echo htmlentities($res->lname);?>">
							</div>
					</div>	
						<div class="row">
							<div class="col-sm-4 form-group">
								<label>Gender</label>

		 						<select class="form-control input-sm" name="gender" readonly id="gender" required="required" >
        							<option VALUE="" disabled selected>Select Gender</option>
        							<option name="gender" required="required" id="male" value="Male">Male</option>
        							<option name="gender" required="required" id="female" value="feale">Female</option>
        							<option name="gender" required="required" id="other" value="other">Other</option>
        
       							</select>
							</div>
							<div class="col-sm-4 form-group">
								<label>Date of Birth</label>
								<input readonly type="date" class="form-control input-sm">

							</div>
							<div class="col-sm-4 form-group">
								<label>Cast</label>

								<select class="form-control input-sm" readonly name="category"  id="category" required="required" >
        							<option VALUE="" readonly selected>Select Category</option>
        							<option VALUE="general">General</option>
       								<option value="obc">OBC</option>
        							<option value="sc">SC</option>
        							<option value="st">ST</option>
									<option value="other">Other</option>
       							</select>
							</div>
						</div>
						

						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Guardian Name</label>
								<input readonly class="form-control" name="gname" required="required" value="<?php echo htmlentities($res->gname);?>">
							</div>
							
							<div class="col-sm-6 form-group">
								<label>Physically Challanged</label>
								<select class="form-control" name="ph"  id="ph"required="required" >
        <option VALUE="<?php echo htmlentities(strtoupper($res->pchal));?>"><?php echo htmlentities(strtoupper($res->pchal));?></option>
        <option VALUE="yes">Yes</option>
        <option value="no">No</option>
               
       </select>
							</div>
						</div>
					</div>	
					
<!-- Contact Information -->

				<div class="col-lg-12 well">
						<p class="w3-opacity w3-card" style=" font-size: 20px">Contact Information</p>
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Email Address</label>
								<input class="form-control"  type="email" name="email" required="required" 
			value="<?php echo htmlentities($res->emailid);?>">	
							</div>
							<div class="col-sm-6 form-group">
								<label>Mobile</label>
								<input class="form-control" type="number" name="mobno" required="required" maxlength="10" 
			   value="<?php echo htmlentities($res->mobno);?>">
							</div>
							
						</div>

						<div class="row">
							<div class="col-sm-4 form-group">
								<label>State</label>
								<select readonly name="state" id="state"  class="form-control input-sm" onchange="showDist(this.value)" required="required">
        							<option value="" disabled selected>Select State</option>
        						</select>
							</div>	
							<div class="col-sm-4 form-group">
								<label>City</label>
								<select readonly name="dist" id="dist"  class="form-control input-sm" onchange="" required="required">
        							<option value="" disabled selected>Select City</option>
								</select>
							</div>	
							<div class="col-sm-4 form-group">
								<label>Zip</label>
								<input readonly type="number" placeholder="Enter Zip Code Here.." class="form-control input-sm">
							</div>	
							 	
						</div>
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Parmanent Address</label>
								<textarea class="form-control" rows="3" name="padd"><?php echo htmlentities($res->padd);?></textarea>	
							</div>	
							<div class="col-sm-6 form-group">
								<label>Correspondence Address</label>
							 <textarea class="form-control" rows="3" name="cadd"><?php echo htmlentities($res->cadd);?></textarea>
							</div>
						</div>

					</div>


<!-- Educational Qualification -->
					<div class="col-lg-12 well">
						<p class="w3-opacity w3-card" style=" font-size: 20px">Educational Qualification</p>
						<div class="row">
							<div class="col-sm-4 form-group">
								<label>Intermadiate Board Name</label>
								<input readonly class="form-control" type="text" name="board1" value="<?php echo htmlentities($res->board);?>">
							</div>
							<div class="col-sm-4 form-group">
								<label>Percentage</label>
								<input readonly class="form-control" type="text" name="roll1" value="<?php echo htmlentities($res->roll);?>">
							</div>
							<div class="col-sm-4 form-group">
								<label>Year Of Passing</label>
								<input readonly class="form-control"  type="text" name="pyear1" value="<?php echo htmlentities($res->pyear);?>">
							</div>
							
						</div>
						<div class="row">
							<div class="col-sm-4 form-group">
								<label>10<sup>th</sup> Board Name</label>
								<input readonly class="form-control" type="text" name="board2" value="<?php echo htmlentities($res->board1);?>">
							</div>
							<div class="col-sm-4 form-group">
								<label>Percentage</label>
								<input readonly class="form-control" type="text" name="roll2" value="<?php echo htmlentities($res->roll1);?>">
							</div>
							<div class="col-sm-4 form-group">
								<label>Year Of Passing</label>
								<input readonly class="form-control"  type="text" name="pyear2" value="<?php echo htmlentities($res->yop1);?>">
							</div>
							
						</div>

						

					</div>





						<div class="row">
						<div class="form-group">
								
								<button type="submit" class="btn btn-lg btn-info" name="submit" value="Update">Submit</button>	
						</div>  
						</div>
						
					</form>
				</div>	
			</div>
</div>
	
	<?php include('footer.php'); ?>




	
<script>
function showState(val) {
    
  	$.ajax({
	type: "POST",
	url: "subject.php",
	data:'id='+val,
	success: function(data){
	  // alert(data);
		$("#state").html(data);
	}
	});
}

function showDist(val) {
    
  	$.ajax({
	type: "POST",
	url: "subject.php",
	data:'did='+val,
	success: function(data){
	  // alert(data);
		$("#dist").html(data);
	}
	});
	
}



							//AJAX
function showSub(val) {
    
    //alert(val);
  	$.ajax({
	type: "POST",
	url: "subject.php",
	data:'cid='+val,
	success: function(data){
	  // alert(data);
		$("#c-full").val(data);
	}
	});
	
}
</script>

</form>
</body>

</html>
