
<nav class="navbar navbar-default navbar-static-top"  role="navigation"
      style="margin-bottom: 0">
			<div class="navbar-header" >
				<button type="button" class="navbar-toggle" data-toggle="collapse"
					data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span> <span
						class="icon-bar"></span> <span class="icon-bar"></span> <span
						class="icon-bar"></span>
				</button>   
        <a class="navbar-brand " href="#">MIZORAM UNIVERSITY</a>
         <a class="navbar-brand" href="#">Student Information System</a>
			</div>
						 <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        <li>
                   <a href="stuhome.php"><span class="glyphicon glyphicon-home" style="font-size:18px;"></span>  Home</a>
                        </li>
                        <li>
                            <a href="#"><span class="glyphicon glyphicon-education" style="font-size:18px;"></span>  Course<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">                                
                                <li>
                                    <a href="view-course2.php">View</a>
                                </li>
                            </ul>
                            </li>
                
                 <li>
                            <a href="#"><span class="glyphicon glyphicon-briefcase" style="font-size:18px;"></span>  Department<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">                                
                                <li>
                                    <a href="view-department2.php">View</a>
                                </li>
                            </ul>
                           
                        </li>
                        
                   <li>
                            <a href="#"><span class="glyphicon glyphicon-user" style="font-size:18px;"></span>  Students<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">                                
                                <li>
                                    <a href="view2.php">View Students</a>
                                </li>
                                                               
                            </ul>
                  </li>     
                                            
                       
                  
                   <li>
                            <a href="logout2.php"><span class="glyphicon glyphicon-off style="font-size:18px;""></span>  Logout<span class="fa arrow"></span></a>
                  </li>
                  </ul>      				  
                </div>
               
            </div>
            
        </nav>