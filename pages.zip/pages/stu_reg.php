<?php
session_start ();

if (! (isset ( $_SESSION ['login'] ))) {
	
	header ( 'location:../index.php' );
}
include('../config/DbFunction.php');
	$obj=new DbFunction();

	
	$rs=$obj->showCourse();
	$rs1=$obj->showCountry();
	$ses=$obj->showSession();
	$res1=$ses->fetch_object();
	//$res1->session;
	if(isset($_POST['submit'])){
		extract($_POST);
		$mob="/^[1-9][0-9]*$/";
		if(!preg_match($mob, $mobno)) 
    $msg="Please enter a valid number";

     
     $obj->register($_POST['course-short'],
     				$_POST['department-short'],
     				$_POST['fname'],
     				$_POST['mname'],
     				$_POST['lname'],
     				$_POST['gender'],
     	            $_POST['gname'],
     	            $_POST['ocp'],
     	            $_POST['income'],
     	            $_POST['category'],
     	            $_POST['ph'],
     	            $_POST['nation'], 
     	            $_POST['mobno'],
     	            $_POST['email'],
     	            $_POST['country'],
     	            $_POST['state'],
     	            $_POST['dist'],
     	            $_POST['padd'],
     	            $_POST['cadd'],
     	            $_POST['board1'],
     	            $_POST['board2'],
     	            $_POST['roll1'],
     	            $_POST['roll2'],
     	            $_POST['pyear1'],
     	            $_POST['pyear2'],
     	            $_POST['session']);
     	            
     	            

	
}
?>



<?php include('../inc/navbar2.php'); ?>

<div class="w3-content" style="max-width:2000px; margin-top:16px">

  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">

  	<h2 class="w3-wide">Registration Form</h2>
    <p class="w3-opacity"><i>School Of Engineering And Technology</i></p>

    <form method="post" >
<!-- Academic Information -->
			<div class="col-lg-12 well">
				<p class="w3-opacity w3-card" style=" font-size: 20px">Academic Information</p>
				<div class="row">
					<div class="col-sm-12">

						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Applying For</label>
								<input class="form-control input-sm" name="session" value="<?php echo htmlentities($res1->session);?>" readonly>
								
							</div>
							<div class="col-sm-6 form-group">
								<label>Batch</label>
								<input class="form-control input-sm" name="session" value="<?php echo htmlentities($res1->session);?>" readonly>
									
							</div>
						
							
						</div>



						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Program</label>
								<select class="form-control courseSelect input-sm"  autofocus="select" name="course-short" id="cshort"  required="required" >			
								<option VALUE="" disabled selected>Select Course</option>
									<?php while($res=$rs->fetch_object()){?>							
			
                        		<option VALUE="<?php echo htmlentities($res->cshort);?>"><?php echo htmlentities($res->cshort)?></option>
                        
                        
                    				<?php }?>   
                    		</select>
							</div>
							<div class="col-sm-6 form-group">
								<label>Department</label>
									<select class="form-control deptSelect input-sm" name="department-short" id="dshort"  required="required" >			
										<option VALUE="">Select Department</option>
				  					</select>
							</div>
						
							
						</div>
					</div>	
				</div>	
			</div>


<!-- Personal Information -->
				<div class="col-lg-12 well">
					<p class="w3-opacity w3-card" style=" font-size: 20px">Personal Information</p>
					<div class="row">
							<div class="col-sm-4 form-group">
								<label>First Name</label>
								<input class="form-control input-sm" name="fname" placeholder="Enter Here.." required="required"  autocomplete="off" pattern="[A-Za-z]+$">
							</div>
							<div class="col-sm-4 form-group">
								<label>Middle Name</label>
								<input class="form-control input-sm" name="mname"  placeholder="Enter Here.." autocomplete="off" pattern="[A-Za-z]+$">
							</div>
							<div class="col-sm-4 form-group">
								<label>Last Name</label>
								<input class="form-control input-sm" name="lname" placeholder="Enter Here.." required="required" autocomplete="off" pattern="[A-Za-z]+$">
							</div>
					</div>	
						<div class="row">
							<div class="col-sm-4 form-group">
								<label>Gender</label>
		 						<select class="form-control input-sm" name="gender"  id="gender" required="required" >
        							<option VALUE="" disabled selected>Select Gender</option>
        							<option name="gender" required="required" id="male" value="Male">Male</option>
        							<option name="gender" required="required" id="female" value="feale">Female</option>
        							<option name="gender" required="required" id="other" value="other">Other</option>
        
       							</select>
							</div>
							<div class="col-sm-4 form-group">
								<label>Date of Birth</label>
								<input type="date" class="form-control input-sm">
							</div>
							<div class="col-sm-4 form-group">
								<label>Cast</label>
								<select class="form-control input-sm" name="category"  id="category" required="required" >
        							<option VALUE="" disabled selected>Select Category</option>
        							<option VALUE="general">General</option>
       								<option value="obc">OBC</option>
        							<option value="sc">SC</option>
        							<option value="st">ST</option>
									<option value="other">Other</option>
       							</select>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Country</label>
								<select class="form-control input-sm" name="country" id="country" onchange="showState(this.value)" required="required" >			

									<option VALUE="" disabled selected>Select Country</option>
									<?php while($res=$rs1->fetch_object()){?>							
			
   									<option VALUE="<?php echo htmlentities($res->id);?>"><?php echo htmlentities($res->name)?></option>
                        
                        
              					      <?php }?>   
                 				</select>
							</div>
							<div class="col-sm-6 form-group">
								<label>Religion</label>
								<input type="text" placeholder="Enter Here.." class="form-control input-sm">
							</div>
							
						</div>

						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Guardian Name</label>
								<input class="form-control input-sm" name="gname"  autocomplete="off" placeholder="Enter Here.." required="required">
							</div>
							
							<div class="col-sm-6 form-group">
								<label>Physically Challanged</label>
								<select class="form-control input-sm" name="ph"  id="ph" required="required" >
        							<option VALUE="">Select If Any</option>
        							<option VALUE="yes">Yes</option>
        							<option value="no">No</option>
               
       </select>
							</div>
						</div>
					</div>	
					
<!-- Contact Information -->

				<div class="col-lg-12 well">
						<p class="w3-opacity w3-card" style=" font-size: 20px">Contact Information</p>
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Email Address</label>
								<input class="form-control input-sm"  type="email" placeholder="abc@gmail.com" required="required" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" name="email">
							</div>
							<div class="col-sm-6 form-group">
								<label>Mobile</label>
								<input class="form-control input-sm" type="number" name="mobno" required="required" pattern="[0-9]{10}$">
							</div>
							
						</div>

						<div class="row">
							<div class="col-sm-4 form-group">
								<label>State</label>
								<select name="state" id="state"  class="form-control input-sm" onchange="showDist(this.value)" required="required">
        							<option value="" disabled selected>Select State</option>
        						</select>
							</div>	
							<div class="col-sm-4 form-group">
								<label>City</label>
								<select name="dist" id="dist"  class="form-control input-sm" onchange="" required="required">
        							<option value="" disabled selected>Select City</option>
								</select>
							</div>	
							<div class="col-sm-4 form-group">
								<label>Zip</label>
								<input type="number" placeholder="Enter Zip Code Here.." class="form-control input-sm">
							</div>	
							 	
						</div>
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Parmanent Address</label>
								<textarea placeholder="Enter Address Here.." rows="3" class="form-control" name="padd" required="required" id="padd"></textarea>
							</div>	
							<div class="col-sm-6 form-group">
								<label>Correspondence Address</label>
							<textarea placeholder="Enter Address Here.." rows="3" class="form-control" name="cadd"  required="required" id="cadd"></textarea>
							</div>
						</div>

					</div>


<!-- Educational Qualification -->
					<div class="col-lg-12 well">
						<p class="w3-opacity w3-card" style=" font-size: 20px">Educational Qualification</p>
						<div class="row">
							<div class="col-sm-4 form-group">
								<label>Intermadiate Board Name</label>
								<input class="form-control input-sm" type="text" required="required" name="board1">
							</div>
							<div class="col-sm-4 form-group">
								<label>Percentage</label>
								<input class="form-control input-sm" type="text" required="required" name="roll1" >
							</div>
							<div class="col-sm-4 form-group">
								<label>Year Of Passing</label>
								<input class="form-control input-sm" type="Year" required="required" name="pyear1" >
							</div>
							
						</div>
						<div class="row">
							<div class="col-sm-4 form-group">
								<label>10<sup>th</sup> Board Name</label>
								<input class="form-control input-sm" type="text" required="required" name="board2" >
							</div>
							<div class="col-sm-4 form-group">
								<label>Percentage</label>
								<input class="form-control input-sm" type="text" required="required" name="roll2" >
							</div>
							<div class="col-sm-4 form-group">
								<label>Year Of Passing</label>
								<input class="form-control input-sm" type="Year" required="required" name="pyear2" >
							</div>
							
						</div>

						

					</div>





						<div class="row">
						<div class="form-group">
								
								<button type="submit" class="btn btn-lg btn-info" name="submit" value="Register">Submit</button>	
						</div>  
						</div>
						
					</form>
				</div>	
			</div>
</div>
	
	<?php include('footer.php'); ?>


		
<script>
function showState(val) {
    
  	$.ajax({
	type: "POST",
	url: "subject.php",
	data:'id='+val,
	success: function(data){
	  // alert(data);
		$("#state").html(data);
	}
	});
}

function showDist(val) {
    
  	$.ajax({
	type: "POST",
	url: "subject.php",
	data:'did='+val,
	success: function(data){
	  // alert(data);
		$("#dist").html(data);
	}
	});
	
}


$('.courseSelect').change(function(){
	var courseName=$(this).val();
	// alert(courseName);
	$.post('fetchDepartment.php',{courseName:courseName},function(data){
		$('.deptSelect').html(data);
	});
});

function showSub(val) {
    
    //alert(val);
  	$.ajax({
	type: "POST",
	url: "subject.php",
	data:'cid='+val,
	success: function(data){
	  alert(data);
		//$("#c-full").val(data);
	}
	});
	
}



</script>
</body>

</html>
